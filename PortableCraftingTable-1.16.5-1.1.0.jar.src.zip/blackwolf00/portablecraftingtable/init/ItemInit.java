/*    */ package blackwolf00.portablecraftingtable.init;
/*    */ 
/*    */ import blackwolf00.portablecraftingtable.Main;
/*    */ import blackwolf00.portablecraftingtable.common.BaseItem;
/*    */ import blackwolf00.portablecraftingtable.common.PortableCraftingTable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.event.RegistryEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.RegistryObject;
/*    */ import net.minecraftforge.registries.ForgeRegistries;
/*    */ import net.minecraftforge.registries.IForgeRegistry;
/*    */ import net.minecraftforge.registries.IForgeRegistryEntry;
/*    */ 
/*    */ public class ItemInit {
/* 23 */   public static final List<Supplier<Item>> BLOCK_ENTRIES = new ArrayList<>();
/*    */   
/* 24 */   public static final Map<RegistryObject<Item>, Supplier<Item>> ENTRIES = new LinkedHashMap<>();
/*    */   
/* 26 */   public static final RegistryObject<Item> PORTABLE_CRAFTING_TABLE = register("portable_crafting_table", () -> new PortableCraftingTable(()));
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRegisterItems(RegistryEvent.Register<Item> event) {
/* 30 */     IForgeRegistry<Item> registry = event.getRegistry();
/* 32 */     BLOCK_ENTRIES.stream().map(Supplier::get).forEach(registry::register);
/* 33 */     ENTRIES.forEach((reg, item) -> {
/*    */           registry.register(item.get());
/*    */           reg.updateReference(registry);
/*    */         });
/*    */   }
/*    */   
/*    */   private static RegistryObject<Item> register(String name) {
/* 41 */     return register(name, () -> new BaseItem(()));
/*    */   }
/*    */   
/*    */   private static RegistryObject<Item> register(String name, Supplier<Item> item) {
/* 45 */     ResourceLocation loc = new ResourceLocation("portablecraftingtable", name);
/* 46 */     RegistryObject<Item> reg = RegistryObject.of(loc, ForgeRegistries.ITEMS);
/* 47 */     ENTRIES.put(reg, () -> (Item)((Item)item.get()).setRegistryName(loc));
/* 48 */     return reg;
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Desktop\PortableCraftingTable-1.16.5-1.1.0.jar!\blackwolf00\portablecraftingtable\init\ItemInit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */