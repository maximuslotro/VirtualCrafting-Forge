/*    */ package blackwolf00.portablecraftingtable;
/*    */ 
/*    */ import blackwolf00.portablecraftingtable.init.ItemInit;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemGroup;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.eventbus.api.IEventBus;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
/*    */ import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ @Mod("portablecraftingtable")
/*    */ public class Main {
/* 19 */   public static final Logger LOGGER = LogManager.getLogger();
/*    */   
/*    */   public static final String MOD_ID = "portablecraftingtable";
/*    */   
/* 21 */   public static final ItemGroup MOD_TAB = new Group("group");
/*    */   
/*    */   public Main() {
/* 25 */     IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
/* 27 */     bus.addListener(this::setup);
/* 29 */     bus.register(new ItemInit());
/* 31 */     MinecraftForge.EVENT_BUS.register(this);
/*    */   }
/*    */   
/*    */   private void setup(FMLCommonSetupEvent event) {}
/*    */   
/*    */   public static class Group extends ItemGroup {
/*    */     public Group(String label) {
/* 41 */       super(label);
/*    */     }
/*    */     
/*    */     public ItemStack func_78016_d() {
/* 46 */       return ((Item)ItemInit.PORTABLE_CRAFTING_TABLE.get()).func_190903_i();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Desktop\PortableCraftingTable-1.16.5-1.1.0.jar!\blackwolf00\portablecraftingtable\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */