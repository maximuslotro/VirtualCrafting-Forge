/*    */ package blackwolf00.portablecraftingtable.common;
/*    */ 
/*    */ import blackwolf00.portablecraftingtable.util.IEnableable;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemGroup;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.NonNullList;
/*    */ 
/*    */ public class BaseItem extends Item {
/*    */   public BaseItem(Function<Item.Properties, Item.Properties> properties) {
/* 13 */     super(properties.apply(new Item.Properties()));
/*    */   }
/*    */   
/*    */   public void func_150895_a(ItemGroup group, NonNullList<ItemStack> items) {
/* 18 */     if (this instanceof IEnableable) {
/* 19 */       IEnableable enableable = (IEnableable)this;
/* 20 */       if (enableable.isEnabled())
/* 21 */         super.func_150895_a(group, items); 
/*    */     } else {
/* 23 */       super.func_150895_a(group, items);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Desktop\PortableCraftingTable-1.16.5-1.1.0.jar!\blackwolf00\portablecraftingtable\common\BaseItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */