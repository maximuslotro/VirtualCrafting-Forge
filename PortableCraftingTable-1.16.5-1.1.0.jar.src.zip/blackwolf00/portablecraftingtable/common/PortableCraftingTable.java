/*    */ package blackwolf00.portablecraftingtable.common;
/*    */ 
/*    */ import blackwolf00.portablecraftingtable.util.IEnableable;
/*    */ import blackwolf00.portablecraftingtable.util.Localizable;
/*    */ import blackwolf00.portablecraftingtable.util.ModConfig;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.entity.player.PlayerInventory;
/*    */ import net.minecraft.inventory.container.Container;
/*    */ import net.minecraft.inventory.container.INamedContainerProvider;
/*    */ import net.minecraft.inventory.container.SimpleNamedContainerProvider;
/*    */ import net.minecraft.inventory.container.WorkbenchContainer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ActionResult;
/*    */ import net.minecraft.util.Hand;
/*    */ import net.minecraft.util.IWorldPosCallable;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class PortableCraftingTable extends BaseItem implements IEnableable {
/*    */   public PortableCraftingTable(Function<Item.Properties, Item.Properties> properties) {
/* 22 */     super(properties.compose(p -> p.func_200917_a(1)));
/*    */   }
/*    */   
/*    */   public ActionResult<ItemStack> func_77659_a(World world, PlayerEntity player, Hand hand) {
/* 27 */     if (!world.func_201670_d())
/* 28 */       player.func_213829_a(getContainer(world, player.func_233580_cy_())); 
/* 31 */     return super.func_77659_a(world, player, hand);
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 37 */     return ((Boolean)ModConfig.ENABLE_PORTABLE_CRAFTING_TABLE.get()).booleanValue();
/*    */   }
/*    */   
/*    */   private INamedContainerProvider getContainer(World world, BlockPos pos) {
/* 41 */     return (INamedContainerProvider)new SimpleNamedContainerProvider((windowId, playerInventory, playerEntity) -> new WorkbenchContainer(windowId, playerInventory, IWorldPosCallable.func_221488_a(world, pos)) {
/*    */           public boolean func_75145_c(PlayerEntity player) {
/* 45 */             return true;
/*    */           }
/* 48 */         }(ITextComponent)Localizable.of("container.crafting").build());
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Desktop\PortableCraftingTable-1.16.5-1.1.0.jar!\blackwolf00\portablecraftingtable\common\PortableCraftingTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */