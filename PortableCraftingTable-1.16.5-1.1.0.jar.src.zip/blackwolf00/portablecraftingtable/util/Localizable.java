/*     */ package blackwolf00.portablecraftingtable.util;
/*     */ 
/*     */ import net.minecraft.util.text.IFormattableTextComponent;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.StringTextComponent;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ 
/*     */ public class Localizable {
/*     */   private final String key;
/*     */   
/*     */   private final TextFormatting defaultColor;
/*     */   
/*     */   protected Localizable(String key) {
/*  13 */     this(key, null);
/*     */   }
/*     */   
/*     */   protected Localizable(String key, TextFormatting defaultColor) {
/*  17 */     this.key = key;
/*  18 */     this.defaultColor = defaultColor;
/*     */   }
/*     */   
/*     */   public static Localizable of(String key) {
/*  22 */     return new Localizable(key);
/*     */   }
/*     */   
/*     */   public static Localizable of(String key, TextFormatting defaultColor) {
/*  26 */     return new Localizable(key, defaultColor);
/*     */   }
/*     */   
/*     */   public String getKey() {
/*  30 */     return this.key;
/*     */   }
/*     */   
/*     */   public TextFormatting getDefaultColor() {
/*  34 */     return this.defaultColor;
/*     */   }
/*     */   
/*     */   public LocalizableBuilder args(Object... args) {
/*  38 */     return builder().args(args);
/*     */   }
/*     */   
/*     */   public LocalizableBuilder color(TextFormatting color) {
/*  42 */     return builder().color(color);
/*     */   }
/*     */   
/*     */   public LocalizableBuilder prepend(String text) {
/*  46 */     return builder().prepend(text);
/*     */   }
/*     */   
/*     */   public IFormattableTextComponent build() {
/*  50 */     return builder().build();
/*     */   }
/*     */   
/*     */   public String buildString() {
/*  54 */     return builder().buildString();
/*     */   }
/*     */   
/*     */   private LocalizableBuilder builder() {
/*  58 */     return (new LocalizableBuilder(this.key)).color(this.defaultColor);
/*     */   }
/*     */   
/*     */   public static class LocalizableBuilder {
/*     */     private final String key;
/*     */     
/*  63 */     private Object[] args = new Object[0];
/*     */     
/*     */     private TextFormatting color;
/*     */     
/*  65 */     private String prependText = "";
/*     */     
/*     */     public LocalizableBuilder(String key) {
/*  68 */       this.key = key;
/*     */     }
/*     */     
/*     */     public LocalizableBuilder args(Object... args) {
/*  72 */       this.args = args;
/*  73 */       return this;
/*     */     }
/*     */     
/*     */     public LocalizableBuilder color(TextFormatting color) {
/*  77 */       this.color = color;
/*  78 */       return this;
/*     */     }
/*     */     
/*     */     public LocalizableBuilder prepend(String text) {
/*  82 */       this.prependText += text;
/*  83 */       return this;
/*     */     }
/*     */     
/*     */     public IFormattableTextComponent build() {
/*     */       IFormattableTextComponent iFormattableTextComponent;
/*  87 */       TranslationTextComponent translationTextComponent = new TranslationTextComponent(this.key, this.args);
/*  89 */       if (!this.prependText.equals(""))
/*  90 */         iFormattableTextComponent = (new StringTextComponent(this.prependText)).func_230529_a_((ITextComponent)translationTextComponent); 
/*  93 */       if (this.color != null)
/*  94 */         iFormattableTextComponent.func_240699_a_(this.color); 
/*  97 */       return iFormattableTextComponent;
/*     */     }
/*     */     
/*     */     public String buildString() {
/* 101 */       return build().getString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\chris\Desktop\PortableCraftingTable-1.16.5-1.1.0.jar!\blackwolf00\portablecraftingtabl\\util\Localizable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */