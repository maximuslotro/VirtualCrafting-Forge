/*    */ package blackwolf00.portablecraftingtable.util;
/*    */ 
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ 
/*    */ public final class ModConfig {
/*    */   public static final ForgeConfigSpec CLIENT;
/*    */   
/*    */   public static final ForgeConfigSpec COMMON;
/*    */   
/*    */   public static final ForgeConfigSpec.BooleanValue ENABLE_PORTABLE_CRAFTING_TABLE;
/*    */   
/*    */   static {
/* 11 */     ForgeConfigSpec.Builder client = new ForgeConfigSpec.Builder();
/* 13 */     CLIENT = client.build();
/* 20 */     ForgeConfigSpec.Builder common = new ForgeConfigSpec.Builder();
/* 21 */     common.comment("Settings for general things.").push("General");
/* 25 */     ENABLE_PORTABLE_CRAFTING_TABLE = common.comment("Should the Portable Crafting Table be enabled?").translation("configGui.handheldfurnace.enable_handheld_furnace").define("portablecraftingtable", true);
/* 26 */     common.pop();
/* 28 */     COMMON = common.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Desktop\PortableCraftingTable-1.16.5-1.1.0.jar!\blackwolf00\portablecraftingtabl\\util\ModConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */