package blackwolf00.portablecraftingtable.util;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ClientUtils {}


/* Location:              C:\Users\chris\Desktop\PortableCraftingTable-1.16.5-1.1.0.jar!\blackwolf00\portablecraftingtabl\\util\ClientUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */