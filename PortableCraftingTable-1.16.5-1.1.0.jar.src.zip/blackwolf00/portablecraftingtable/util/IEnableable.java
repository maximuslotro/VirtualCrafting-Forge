package blackwolf00.portablecraftingtable.util;

public interface IEnableable {
  boolean isEnabled();
}


/* Location:              C:\Users\chris\Desktop\PortableCraftingTable-1.16.5-1.1.0.jar!\blackwolf00\portablecraftingtabl\\util\IEnableable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */